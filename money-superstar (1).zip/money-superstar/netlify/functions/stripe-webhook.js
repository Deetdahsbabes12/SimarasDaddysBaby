const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);

exports.handler = async (event) => {
  const payload = JSON.parse(event.body);

  if (payload.type === "checkout.session.completed") {
    const email = payload.data.object.customer_email;
    const productId = payload.data.object.metadata.product_id;

    await fetch(process.env.ZAPIER_WEBHOOK_URL, {
      method: "POST",
      body: JSON.stringify({ email, productId }),
    });
  }

  return {
    statusCode: 200,
    body: "Payment handled successfully",
  };
};
