const fetch = require("node-fetch");

exports.handler = async () => {
  const response = await fetch("https://api.gumroad.com/v2/products", {
    headers: {
      Authorization: `Bearer ${process.env.GUMROAD_API_KEY}`,
    },
  });

  const products = await response.json();

  return {
    statusCode: 200,
    body: JSON.stringify(products),
  };
};
